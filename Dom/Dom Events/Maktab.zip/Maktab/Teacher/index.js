const address = document.getElementById("address")
const address1 = document.getElementById("address1")
const address2 = document.getElementById("address2")

address.onclick = function(){
    if(address.innerHTML) alert("Osoyishta Street N60")
}
address1.onclick = function(){
    if(address.innerHTML) alert("Niyyat Street N22")
}
address2.onclick = function(){
    if(address.innerHTML) alert("Olmazor street N45")
}
