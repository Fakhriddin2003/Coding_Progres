
        //    let school = {
        //     classes : {
        //         1: {
        //             name: " 10 A - class ",
        //             inform: {
        //                 1: "Oliver",
        //                 2: "Jack",
        //                 3: "Harry",
        //                 4: "Jacob",
        //             },
        //         },
        //           2: {
        //             name: " Class  Staff",
        //             inform: {
        //                 1: "Desk",
        //                 2: "Pen",
        //                 3: "Table",
        //                 4: "Nootebook",
        //             },
                  
        //         },
        //         3: {
        //             name: " 11 A - class ",
        //             inform: {
        //                 1: "Thomas",
        //                 2: "George",
        //                 3: "Oscar",
        //                 4: "James",
        //             },
                  
        //         },
               
        //         4: {
        //             name: " Class Staff ",
        //             inform: {
        //                 1: "Flowers",
        //                 2: "Galery",
        //                 3: "Books",
        //                 4: "Notebook",
        //             },
                  
        //         },
        //              },
        //         showStaffs: function(studentNumber) {
        //             const about = this.classes[studentNumber];
        //             const inform = about && about.inform;

        //             if(inform) {
        //                 console.log(about.name);
        //                 console.log(inform[1], inform[2],inform[3],inform[4],);
        //             } else console.log("error");
        //         },
        //         showClasses: function() {
        //             for (let propName in this.classes) {
        //                 console.log(this.classes[propName].name );
        //                 const inform = this.classes[propName].inform;

        //                 let values = Object.values(inform);
        //                 for(let i = 0; i < values.length; i++) console.log(values[i]);

        //             }
        //         },
        //    };
        //    let obj = JSON.stringify(school);
        //    console.log(obj);
        //    console.log(typeof obj);
         






        // let teachers = {
        //     teachers: {
        //         1: {
        //             name: "Alex Musk",
        //             inform: {
        //                 1: " Math Teacher",
        //                 2: " 881 262 467",
        //                 3: " Brodnowska16a",
        //                 4: " 2.300$",
        //             },
        //         },
        //         2: {
        //             name: "Alexandra Oliver",
        //             inform: {
        //                 1: " History Teacher",
        //                 2: " 244 265 781",
        //                 3: " Briccel Suite ",
        //                 4: " 1.500$",
        //             },
        //         },
        //         3: {
        //             name: "Jack Connor",
        //             inform: {
        //                 1: " Bialogy Teacher",
        //                 2: " 329 339 111",
        //                 3: " Dobiszewskiego 2",
        //                 4: " 2.000$",
        //             },
        //         },
        //         4: {
        //             name: "Paulina Zuzza",
        //             inform: {
        //                 1: " Calculs Teacher",
        //                 2: " 323 555 132",
        //                 3: " New York Street",
        //                 4: " 5.000$",
        //             },
        //         },
        //     },
        //         showInform: function(informNumber) {
        //             const about =  this.teachers[informNumber];
        //             const inform =  about &&  about.inform;
                    
        
        //             if(inform) {
        //                 console.log( about.name);
        //                 console.log(inform[1],inform[2],inform[3],inform[4]);
        //              } else console.log("error");
        
                    
        //         },
        
        //         showTeachers: function () {
        //         for (let propName in this.teachers) {
        //             console.log(this.teachers[propName].name);
        //             const inform = this.teachers[propName].inform;
        
        //             let values = Object.values(inform);
        //             for(let i = 0; i < values.length; i++) console.log(values[i]);
        //         }
        //         },
        // };
        // teachers.showTeachers();
        
        





        

        // let teacher = {

        //     name: " Alex",
        //     surname: " Musk, ",
        //     subject: " Math Teacher",
        //     phoneNumber: " Tel -881262467",
        //     address: " Lives in Brodnowska16a",
        //     salary: "  His Salary - 1000$",
        //     setInfo: function () {
        //         console.log(
        //             this.name,
        //             this.surname,
        //             this.phoneNumber,
        //             this.address,
        //             this.salary,
        //         );
        //     },
        //     showInfo: function () {
        //         console.log(this.name + this.surname + this.subject + this.phoneNumber + this.address + this
        //             .salary);
        //     }
        // };
        // teacher.showInfo();